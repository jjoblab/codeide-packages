set(RESOLV_WRAPPER_LIBRARY /data/data/jo.codeide/files/usr/lib/libresolv_wrapper.so)
