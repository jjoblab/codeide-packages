# 3rd party completion loader for commands emitting their completion using
# "$cmd --generate-completion bash".
#
# This serves as a fallback in case the completion is not installed otherwise.

eval -- "$("$1" --generate-completion bash 2>/dev/null)"
