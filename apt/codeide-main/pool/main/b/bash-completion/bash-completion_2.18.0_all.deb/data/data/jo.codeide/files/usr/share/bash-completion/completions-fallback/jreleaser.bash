# 3rd party completion loader for commands emitting their completion using
# "$cmd generate-completion".
#
# This serves as a fallback in case the completion is not installed otherwise.

eval -- "$("$1" generate-completion 2>/dev/null)"
