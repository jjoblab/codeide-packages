#!/data/data/jo.codeide/files/usr/bin/sh

echo "$@"
