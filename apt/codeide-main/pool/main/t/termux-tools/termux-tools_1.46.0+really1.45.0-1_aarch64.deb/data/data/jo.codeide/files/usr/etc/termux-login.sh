##
## This script is sourced by /data/data/jo.codeide/files/usr/bin/login before executing shell.
##
