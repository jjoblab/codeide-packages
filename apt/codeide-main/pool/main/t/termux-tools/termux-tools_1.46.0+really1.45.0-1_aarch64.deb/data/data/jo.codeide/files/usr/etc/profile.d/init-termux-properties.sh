if [ ! -f /data/data/jo.codeide/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/jo.codeide/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/jo.codeide/files/home/.termux
	cp /data/data/jo.codeide/files/usr/share/examples/termux/termux.properties /data/data/jo.codeide/files/home/.termux/
fi
