%include <javascript/cdata.i>
